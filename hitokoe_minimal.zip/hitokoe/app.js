(()=>{
  'use strict';

  const DAY_LIMIT = 10;
  const COOLDOWN_SEC = 20;
  const FEATHER_STEPS = [3,5,8,10];
  const storeKey = "greet_records_v2";

  const $ = (q)=>document.querySelector(q);
  const $$ = (q)=>Array.from(document.querySelectorAll(q));

  const elCount = $("#count");
  const elStreak = $("#streak");
  const elFeathers = $("#feathers");
  const elCooldown = $("#cooldownMsg");
  const elStatus = $("#status");
  const subtitle = $("#subtitle");
  const note = $("#note");
  const btnExport = $("#export");
  const btnClear = $("#clear");

  const btns = $$("button[data-cat]");

  function dayKey(date = new Date()){
    // "YYYY-MM-DD" in local time using 'sv-SE' locale which formats ISO-like
    return date.toLocaleDateString('sv-SE'); 
  }

  function load(){
    try{
      const raw = JSON.parse(localStorage.getItem(storeKey) || "{}");
      if(!raw.records) raw.records = [];
      if(!raw.meta) raw.meta = {streak:0, lastDay:null, lastTs:0};
      return raw;
    }catch(e){
      return {records:[], meta:{streak:0, lastDay:null, lastTs:0}};
    }
  }
  function save(state){ localStorage.setItem(storeKey, JSON.stringify(state)); }

  function render(state){
    const today = dayKey();
    const todayRecs = state.records.filter(r => r.day === today);
    elCount.textContent = String(todayRecs.length);
    elStreak.textContent = `連続 ${state.meta.streak||0} 日`;
    subtitle.textContent = `${today} の小さな挨拶`;
    renderFeathers(todayRecs.length);
    // cooldown text
    const remains = Math.max(0, (state.meta.lastTs||0) + COOLDOWN_SEC*1000 - Date.now());
    elCooldown.textContent = remains>0 ? `次の登録まで ${Math.ceil(remains/1000)} 秒` : "";
  }

  function renderFeathers(n){
    elFeathers.innerHTML = "";
    FEATHER_STEPS.forEach(step=>{
      const f = document.createElement("div");
      f.className = "feather" + (n>=step ? " on" : "");
      elFeathers.appendChild(f);
    });
  }

  function setStatus(msg, ok){
    elStatus.textContent = msg;
    elStatus.className = ok ? "muted small ok" : "muted small";
    if(msg) setTimeout(()=>{ elStatus.textContent=""; }, 2500);
  }

  function addRecord(cat, noteText){
    const state = load();
    const today = dayKey();
    const todayCount = state.records.filter(r=>r.day===today).length;
    if(todayCount >= DAY_LIMIT){
      setStatus(`今日は上限 ${DAY_LIMIT} 件です`, false);
      return;
    }
    // cooldown
    if((state.meta.lastTs||0) + COOLDOWN_SEC*1000 > Date.now()){
      const wait = Math.ceil(((state.meta.lastTs||0)+COOLDOWN_SEC*1000 - Date.now())/1000);
      setStatus(`少し間を空けましょう（あと ${wait} 秒）`, false);
      return;
    }

    // streak handling: if first record of today, update streak
    if(todayCount === 0){
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate()-1);
      const yKey = dayKey(yesterday);
      const hadYesterday = state.records.some(r=>r.day===yKey);
      // if this is the first ever record (no lastDay), start at 1
      state.meta.streak = (state.meta.lastDay ? (hadYesterday ? (state.meta.streak||0)+1 : 1) : 1);
      state.meta.lastDay = today;
    }

    const rec = {
      ts: Date.now(),
      day: today,
      cat,
      note: (noteText||"").slice(0,80)
    };
    state.records.push(rec);
    state.meta.lastTs = rec.ts;
    save(state);
    note.value = "";
    setStatus("記録しました。", true);
    render(state);
  }

  function exportCSV(){
    const state = load();
    const rows = state.records.map(r=>{
      const d = new Date(r.ts);
      const t = d.toTimeString().slice(0,8);
      return [r.day, t, r.cat, (r.note||"").replace(/\"/g,'\"\"')];
    });
    if(rows.length===0){ setStatus("まだ記録がありません。", false); return; }
    const header = ["date","time","category","note"];
    const csv = [header, ...rows].map(cols=>cols.map(c=>`"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv],{type:"text/csv;charset=utf-8;"});
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "hitokoe_records.csv"; a.click();
    URL.revokeObjectURL(url);
  }

  function clearToday(){
    const state = load();
    const today = dayKey();
    const before = state.records.length;
    state.records = state.records.filter(r=>r.day!==today);
    save(state);
    setStatus(before===state.records.length ? "今日の記録はありません。" : "今日の記録を消去しました。", true);
    render(state);
  }

  // wire
  btns.forEach(b => {
    b.addEventListener("click", ()=> addRecord(b.dataset.cat, note.value.trim()));
  });
  btnExport.addEventListener("click", exportCSV);
  btnClear.addEventListener("click", clearToday);

  // initial render
  render(load());
})();